package burp.payload;

/**
 * Single source of truth for well known and standard AEM paths which are supposed to be reused among various checks
 *
 * @author thomas.hartmann@netcentric.biz
 * @since 02/2019
 */
public enum AEMPath {
}
